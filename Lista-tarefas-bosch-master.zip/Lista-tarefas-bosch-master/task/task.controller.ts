import { Controller } from '@nestjs/common';

@Controller('task')
export class TaskController {}
